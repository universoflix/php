<!DOCTYPE html>
<html lang="pt-br" >
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>PAINEL PRO</title>
  <meta name="viewport" content="width=device-width, initial-scale=1"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.2/css/all.min.css'>
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Handlee|Josefin+Sans:300,600&amp;display=swap'><link rel="stylesheet" href="../style.css">
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<link rel="stylesheet" type="text/css" href="../css/util.css">
<link rel="stylesheet" type="text/css" href="../css/main.css">
</head>

<body>
<?php

include 'updatepag.php';
include('../config.php');
error_reporting(0);
	session_start();
    if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 300)) {
        session_unset();
        session_destroy();
    }
    $validade = [];
    $_SESSION['LAST_ACTIVITY'] = time();
    include '../conexao.php';
    include '../config.php';

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    ?>

<!-- partial:index.partial.html -->
<div class="container">
  <div class="card-wrap">
    <div class="card border-0 shadow card--welcome is-show" id="welcome">
      <div class="card-body">
      <button class="btn btn-back js-btn" onclick="window.location.href = '../home.php'" data-target="welcome"><i class="fas fa-angle-left"></i></button>
      
      <img class="img" name="img" src="../images/logo.png" width="200" height="150"/>
   
      <form class="login100-form validate-form" action="updatepag.php" method="post">
					 <h2 class="card-title">Configurações de Pagamento</h2>
					
                    <div class="wrap-input100 validate-input" data-validate="Enter password">
						<span class="btn-show-pass">
							<i class="zmdi zmdi-eye"></i>
						</span>
                        <h5>Access token Mercado Pago</h5><a href="https://www.mercadopago.com.br/business"><button>Clique aqui para ir a pagina do Mercado Pago</button></a>
						<input type="text" name="acesstokenmp" placeholder="">
						<span class="focus-input100" data-placeholder=""></span>
					</div>
                    <div class="wrap-input100 validate-input" data-validate="Enter password">
						<span class="btn-show-pass">
							<i class="zmdi zmdi-eye"></i>
						</span>
                        <h6>Valor do Login Para Usuario Final</h6>

						<input type="text" name="valorusuariofinal" placeholder="" valor="localhost">
						<span class="focus-input100" data-placeholder=""></span>
					</div>
                    <div class="wrap-input100 validate-input" data-validate="Enter password">
						<span class="btn-show-pass">
							<i class="zmdi zmdi-eye"></i>
						</span>
                        <h6>Valor de Cada Login Para Revenda (Caso não queira usar defina todos como 1 e salve)</h6>

						<input type="text" name="valorcadarevenda" placeholder="" valor="ipservidor">
						<span class="focus-input100" data-placeholder=""></span>
					</div>

					<div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
                            <!-- ao clicar em instalar chamar php -->
							<button class="login100-form-btn" name="salvar" id="salvar" >
                                Salvar
                            </button>
					</div>
            <?php

					
               if (isset($_POST['valorcadarevenda']) && isset($_POST['valorusuariofinal']) && isset($_POST['acesstokenmp']));


        ?>
				</form>
       

     
      </div>
      </div>

    
  </body>
</html>