<?php
error_reporting(0);
include('../conexao.php');
session_start();
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if (isset($_POST['salvar'])) {
    $acesstokenmp = $_POST['acesstokenmp'];
    $valorusuariofinal = $_POST['valorusuariofinal'];
    $valorcadarevenda = $_POST['valorcadarevenda'];
    
                $sql = "UPDATE accounts SET accesstoken = '$acesstokenmp' WHERE id = '" . $_SESSION['iduser'] . "'";
                $sql2 = "UPDATE accounts SET valorusuario = '$valorusuariofinal' WHERE id = '" . $_SESSION['iduser'] . "'";
                $sql3 = "UPDATE accounts SET valorrevenda = '$valorcadarevenda' WHERE id = '" . $_SESSION['iduser'] . "'";
                if ($conn->query($sql) === TRUE) {
                } else {
                }

                if ($conn->query($sql2) === TRUE) {
                } else {
                }

                if ($conn->query($sql3) === TRUE) {
                } else {
                }
            }
            if(isset($_POST['salvar'])){
                echo('<script>window.location.href = "../home.php";</script>');
                echo ('<script>alert("Dados atualizados com sucesso!");</script>');
                }
?>